#include<iostream.h>
#include<conio.h>
const m=50;
class items
{
	int itemCode[m];
	float itemPrice[m];
	int cnt;

	public:

	void count(void){cnt=0;}
	void getitem();
	void displaySum();
	void remove();
	void displayItems();
};
void items:: getitem()
{
	cout<<"Enter item code : ";
	cin>>itemCode[cnt];
	cout<<"Enter Item cost : ";
	cin>>itemPrice[cnt];
	cnt++;
}
void items:: displaySum()
{
	float sum=0;
	for(int i=0;i<cnt;i++)
	sum=sum+itemPrice[i];
	cout<<"\n Total Item Cost Value:"<<sum<<"\n";
}
void items:: remove()
{
	int a;
	cout<<"\nEnter Item Code which you want to delete : ";
	cin>>a;
	for(int i=0;i<cnt;i++)
	{
		if(itemCode[i] == a)
		{
			itemCode[i]=0;
			itemPrice[i]=0;
		}
	}
}
void items :: displayItems()
{
	cout<<"\nITEM CODE\tITEM COST\n";
	for(int i=0;i<cnt;i++)
	{
		cout<<"\n"<<itemCode[i]<<"\t\t"<<itemPrice[i];
	}
	cout<<"\n";
}
void main()
{
	clrscr();
	items i;
	i.count();
	int x;
	do
	{
		cout<<"\n     -------CHOICES-------";
		cout<<"\n1.Add an Item";
		cout<<"\n2.Display Total Cost Value";
		cout<<"\n3.Delete an Item";
		cout<<"\n4.Display all items";
		cout<<"\n5.Quit";

		cout<<"\n\nEnter Your Choice : ";
		cin>>x;

		switch(x)
		{
			case 1:
			i.getitem();
			break;

			case 2:
			i.displaySum();
			break;

			case 3:
			i.remove();
			break;

			case 4:
			i.displayItems();
			break;

			case 5:
			break;

			default:
			cout<<"Enter appropriate choice...";
		}
	}while(x!=5);
	getch();
}